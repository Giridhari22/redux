const initialState={
    
    list:[],
    member:''
}

const reducer = (state=initialState , action)=>{
    console.log(state)
switch(action.type){
    case "input":
        return { ...state, member: action.payload };
    case "add":
        return {...state , list: [...state.list , state.member]}
    case "delete":
        const newlist = state.list.filter((item)=>
            {
                if(item!==action.payload)
                {
                    return item
                }  
            })
        return {...state , list:newlist}
    default:
   return state
}
}
export default reducer