import { useSelector, useDispatch } from 'react-redux'


const Task = () => {
    const dispatch = useDispatch()
    const state = useSelector((state) => state)

    const Inc = () => {
        dispatch({ type: "Inc" })
    }

    const Dec = () => {
        dispatch({ type: "Dec" })
    }
    const handleChange = (e) => {
        const newNum = e.target.value
        dispatch({ type: "input", payload: newNum })
    }
    const add = () => {
        dispatch({ type: "add" })
    }
    const sub = () => {
        dispatch({ type: "sub" })

    }
    const colour = () => {
        dispatch({ type: "colour" })
    }

    return (
        <div>
            <p>{state.count}</p>
            <input onChange={handleChange} value={state.num} />
            <div>
                <button onClick={add}>add</button>
                <button onClick={sub}>sub</button>
            </div>
            <button onClick={Inc}>Inc</button>
            <button onClick={Dec}>Dec</button>
            <p style={{ backgroundColor: state.colour }}>colour:{state.colour}</p>
            <button onClick={colour}>color change</button>

        </div>
    )
}
export default Task