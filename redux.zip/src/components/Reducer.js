const initialState = {
    count: 0,
    num: 0,
    colour:"green"
}



const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "add":
            return { ...state, count: state.count + +state.num }
        case "sub":
            return { ...state, count: state.count - +state.num }
        case "input":
            return { ...state, num: +action.payload };
        case "Inc":
            return { ...state, count: state.count + 1 }
        case "Dec":
            return { ...state, count: state.count - 1 }
        case "colour":
            let arr = ["blue", "red", "yellow", "pink", "violet"]
            let index = Math.floor((Math.random()*arr.length))
            console.log(index)
            return { ...state, colour: state.colour = arr[index]}
        default:
            return state;
    }
}
export default reducer