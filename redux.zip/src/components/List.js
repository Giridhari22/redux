import react, { useState } from "react";
import { useSelector, useDispatch } from 'react-redux'

const name = []

const List =()=>{
    const dispatch = useDispatch()
    const state = useSelector((state) => state)
    const handelDelete=(val)=>{
        dispatch({type:"delete" , payload:val})

       
    }

    const handleAdd=()=>{
         dispatch({type:"add"})
       
    }
const handleChange = (e)=>{
    const newMem = e.target.value
    dispatch({ type: "input", payload: newMem })
}
    return(
     <>
     <input value={state.member} onChange={handleChange} />
     <button onClick={handleAdd}>Add name</button>
        <ul>
     {   
        state.list.map((value)=>{
            return(
                <>
                <li>{value}
                <button onClick={()=>{handelDelete(value)}}>Delete </button>
                </li>
                
                </>

            )

        })
    }
    </ul>
     </>
    )
}
export default List